from twilio.rest import Client
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

class Communicator:
    def __init__(self, twilio_sid, twilio_token, twilio_phone, sendgrid_key, from_email):
        self.twilio_sid = twilio_sid
        self.twilio_token = twilio_token
        self.twilio_phone = twilio_phone
        self.sendgrid_key = sendgrid_key
        self.from_email = from_email

        # Initialisation des clients Twilio et SendGrid
        self.twilio_client = Client(self.twilio_sid, self.twilio_token)
        self.sendgrid_client = SendGridAPIClient(self.sendgrid_key)

    def send_sms(self, to_phone_number, message_body):
        try:
            message = self.twilio_client.messages.create(
                to=to_phone_number,
                from_=self.twilio_phone,
                body=message_body
            )
            print(f"SMS envoyé avec succès. SID: {message.sid}")
        except Exception as e:
            print(f"Erreur lors de l\'envoi du SMS: {e}")

    def send_email(self, to_email, subject, html_content):
        message = Mail(
            from_email=self.from_email,
            to_emails=to_email,
            subject=subject,
            html_content=html_content
        )
        try:
            response = self.sendgrid_client.send(message)
            print(f"E-mail envoyé avec succès. Statut: {response.status_code}")
            print(response.body)
            print(response.headers)
        except Exception as e:
            print(f"Erreur lors de l\'envoi de l\'e-mail: {e}")


