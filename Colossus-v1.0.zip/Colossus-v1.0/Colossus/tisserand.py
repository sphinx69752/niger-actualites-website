import json

class Tisserand:
    def __init__(self, clients_file):
        self.clients_file = clients_file

    def analyser_clients(self):
        try:
            with open(self.clients_file, 'r', encoding='utf-8') as f:
                clients_data = json.load(f)
        except FileNotFoundError:
            print(f"Erreur: Le fichier {self.clients_file} n'a pas été trouvé.")
            return []
        except json.JSONDecodeError:
            print(f"Erreur: Le fichier {self.clients_file} n'est pas un JSON valide.")
            return []

        recommandations = []
        for client in clients_data:
            if client['age'] > 60 and client['fidelite_ans'] > 10:
                recommandations.append(f"Proposer un programme de fidélité premium au client {client['nom']} (âge: {client['age']}, fidélité: {client['fidelite_ans']} ans).")
            elif client['revenu_annuel'] < 30000 and client['depenses_mensuelles'] > 1000:
                recommandations.append(f"Offrir des conseils budgétaires au client {client['nom']} (revenu: {client['revenu_annuel']}, dépenses: {client['depenses_mensuelles']}).")
            # Ajoutez d'autres règles d'analyse ici

        return recommandations


