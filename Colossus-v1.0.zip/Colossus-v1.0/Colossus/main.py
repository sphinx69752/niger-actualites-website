import os
from flask import Flask, jsonify
from dotenv import load_dotenv

# Importer les modules de Colossus
from tisserand import Tisserand
from argentier import Argentier
from stratege import Stratege
from communicator import Communicator

# Charger les variables d'environnement (utile pour les tests locaux)
# Sur Render, ces variables seront directement injectées dans l'environnement.
load_dotenv()

# --- Initialisation de l'application Flask ---
# Render a besoin d'un service web pour fonctionner.
# Flask crée un point de terminaison web simple pour maintenir le service actif.
app = Flask(__name__)

# --- Configuration des modules de Colossus ---
def run_colossus_analysis():
    """
    Fonction principale qui exécute l'analyse complète de Colossus.
    """
    print("Lancement de l'analyse Colossus...")

    # 1. Initialiser les modules d'analyse
    # Les chemins vers les fichiers de données sont spécifiés ici.
    tisserand = Tisserand(clients_file='data/clients.json')
    argentier = Argentier(finances_file='data/finances.json')
    
    # Le Stratege n'a pas besoin de fichier, il synthétise les résultats.
    stratege = Stratege()

    # 2. Exécuter les analyses
    print("Analyse des clients par le Tisserand...")
    recommandations_clients = tisserand.analyser_clients()
    
    print("Analyse des finances par l'Argentier...")
    recommandations_financieres = argentier.analyser_finances()

    # 3. Prioriser les actions avec le Stratège
    print("Priorisation des actions par le Stratège...")
    actions_priorisees = stratege.prioriser_actions(recommandations_clients, recommandations_financieres)

    print("Analyse terminée.")
    return actions_priorisees

def send_report(actions):
    """
    Envoie le rapport d'analyse via SMS et e-mail.
    """
    print("Préparation de l'envoi des notifications...")

    # Récupérer les clés API et les informations depuis les variables d'environnement
    twilio_sid = os.getenv('TWILIO_ACCOUNT_SID')
    twilio_token = os.getenv('TWILIO_AUTH_TOKEN')
    twilio_phone = os.getenv('TWILIO_PHONE_NUMBER')
    sendgrid_key = os.getenv('SENDGRID_API_KEY')
    from_email = os.getenv('FROM_EMAIL')
    
    # Le numéro de téléphone et l'e-mail du destinataire
    # Pour le moment, nous pouvons les coder en dur ou les mettre dans les variables d'environnement.
    # Assure-toi que TO_PHONE_NUMBER est bien ton numéro personnel au format E.164 (+336...).
    to_phone_number = os.getenv('YOUR_PERSONAL_PHONE_NUMBER') # À ajouter dans Render
    to_email = os.getenv('YOUR_PERSONAL_EMAIL') # À ajouter dans Render

    # Vérification que toutes les clés sont présentes
    if not all([twilio_sid, twilio_token, twilio_phone, sendgrid_key, from_email, to_phone_number, to_email]):
        print("ERREUR : Toutes les variables d'environnement ne sont pas définies.")
        print("Veuillez vérifier TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER, SENDGRID_API_KEY, FROM_EMAIL, YOUR_PERSONAL_PHONE_NUMBER, et YOUR_PERSONAL_EMAIL.")
        return

    # Initialiser le Communicator avec les clés
    communicator = Communicator(
        twilio_sid=twilio_sid,
        twilio_token=twilio_token,
        twilio_phone=twilio_phone,
        sendgrid_key=sendgrid_key,
        from_email=from_email
    )

    # --- Formatage du message ---
    # Message pour le SMS (plus court)
    sms_body = "Rapport Colossus:\n" + "\n".join([f"- {action}" for action in actions[:3]]) # Les 3 actions les plus prioritaires

    # Contenu pour l'e-mail (plus détaillé)
    email_subject = "Rapport d'analyse quotidien de Colossus"
    email_html_content = "<h1>Rapport d'analyse Colossus</h1>"
    email_html_content += "<h2>Actions prioritaires recommandées :</h2>"
    email_html_content += "<ul>"
    for action in actions:
        email_html_content += f"<li>{action}</li>"
    email_html_content += "</ul>"
    email_html_content += "<p>Analyse effectuée avec succès.</p>"

    # --- Envoi des notifications ---
    # Envoi du SMS
    print(f"Envoi du SMS à {to_phone_number}...")
    communicator.send_sms(to_phone_number, sms_body)

    # Envoi de l'e-mail
    print(f"Envoi de l'e-mail à {to_email}...")
    communicator.send_email(to_email, email_subject, email_html_content)
    
    print("Notifications envoyées.")


# --- Point d'entrée de l'application Flask ---
@app.route('/')
def home():
    """
    Point de terminaison principal pour vérifier que le service est en ligne.
    """
    return "Le service Colossus est en ligne et fonctionnel."

@app.route('/run-analysis')
def trigger_analysis():
    """
    Point de terminaison pour déclencher manuellement l'analyse et l'envoi du rapport.
    """
    try:
        actions = run_colossus_analysis()
        send_report(actions)
        return jsonify({"status": "success", "message": "Analyse terminée et rapport envoyé.", "actions": actions})
    except Exception as e:
        # Gestion basique des erreurs
        print(f"Une erreur est survenue : {e}")
        return jsonify({"status": "error", "message": str(e)}), 500


# --- Exécution principale ---
if __name__ == '__main__':
    # Déclenche l'analyse et l'envoi du rapport au démarrage du script
    # C'est ce que Render exécutera avec "python main.py"
    actions_result = run_colossus_analysis()
    send_report(actions_result)

    # Lance le serveur Flask pour maintenir l'application active
    # Render a besoin que l'application écoute sur un port défini par la variable PORT.
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)


