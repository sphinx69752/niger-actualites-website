class Stratege:
    def __init__(self):
        pass

    def prioriser_actions(self, recommandations_clients, recommandations_financieres):
        actions_priorisees = []

        # Exemple de logique de priorisation simple
        # Les recommandations financières sont souvent plus urgentes
        actions_priorisees.extend(recommandations_financieres)
        actions_priorisees.extend(recommandations_clients)

        # Ici, vous pouvez ajouter une logique plus complexe de tri ou de filtrage
        # Par exemple, trier par impact potentiel, urgence, etc.
        # Pour l'instant, c'est une simple concaténation.

        return actions_priorisees


