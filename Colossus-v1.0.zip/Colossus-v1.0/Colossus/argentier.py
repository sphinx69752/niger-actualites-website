import json

class Argentier:
    def __init__(self, finances_file):
        self.finances_file = finances_file

    def analyser_finances(self):
        try:
            with open(self.finances_file, 'r', encoding='utf-8') as f:
                finances_data = json.load(f)
        except FileNotFoundError:
            print(f"Erreur: Le fichier {self.finances_file} n'a pas été trouvé.")
            return []
        except json.JSONDecodeError:
            print(f"Erreur: Le fichier {self.finances_file} n'est pas un JSON valide.")
            return []

        recommandations = []
        for item in finances_data:
            if item['type'] == 'depense' and item['montant'] > 500:
                recommandations.append(f"Examiner la dépense élevée de {item['montant']}€ pour {item['description']}.")
            elif item['type'] == 'revenu' and item['montant'] < 100:
                recommandations.append(f"Identifier les sources de revenus faibles comme {item['description']} ({item['montant']}€).")
            # Ajoutez d'autres règles d'analyse ici

        return recommandations


